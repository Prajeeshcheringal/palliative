<?php

namespace App\Model\home_visit;

use Illuminate\Database\Eloquent\Model;

class HomeVisit extends Model
{
    //
}
