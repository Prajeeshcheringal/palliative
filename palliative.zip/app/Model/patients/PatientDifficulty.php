<?php

namespace App\Model\patients;

use Illuminate\Database\Eloquent\Model;

class PatientDifficulty extends Model
{
    protected $fillable=['pat_id','dificulty'];
}
