@extends('layouts.app')

@section('content')


<script>window.location = "{{url('/home')}}";</script>


@endsection
