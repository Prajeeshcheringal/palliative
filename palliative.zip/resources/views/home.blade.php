@extends('layouts.app')

@section('content')

<!-- <section class="content-header">
  <h1>
    Dashboard
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Here</li>
  </ol>
</section> -->
<br>
<div class="row">

  <a href="{{url('/patients')}}" style="color: black;">
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-green"><i class="ion ion-ios-people-outline"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Active Patients</span>
          <span class="info-box-number">{{$active_patients}}</span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
  </a>
  <!-- /.col -->


  <a href="{{url('/reports/patients')}}" style="color: black;">
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-aqua"><i class="ion ion-ios-people-outline"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Total Patients</span>
          <span class="info-box-number">{{$total_patients}}<small></small></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
  </a>
  <!-- /.col -->
  <a href="{{url('/dailypatients')}}" style="color: black;">
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-yellow"><i class="fa  fa-medkit"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Daily Clinic Care</span>
          <span class="info-box-number">{{$daily_clinic_care}}</span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
  </a>
  <!-- /.col -->

  <!-- fix for small devices only -->
  <div class="clearfix visible-sm-block"></div>
  <a href="{{url('/bookings')}}" style="color: black;">
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-violet"><i class="fa fa-home"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Daily Home Care</span>
          <span class="info-box-number">{{$daily_home_care}}</span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
  </a>

</div>
<br>


<div class="row">

  <div class="clearfix visible-sm-block"></div>

  <a href="{{url('/bookings/pendings')}}" style="color: black;">
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-red"><i class="fa fa-home"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Pending Home Care</span>
          <span class="info-box-number">{{$pending_home_care}}</span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
  </a>

</div>




<script>
  $(function() {


    sessionStorage.removeItem("selectedli");
    sessionStorage.removeItem("selecteditem");

  })
</script>
@endsection